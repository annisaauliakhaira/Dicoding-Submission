package com.example.tugas.wisatasubmission;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rvWisatas;
    private ArrayList<Wisata> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvWisatas = findViewById(R.id.rv_wisatas);
        rvWisatas.setHasFixedSize(true);

        list.addAll(WisatasData.getListData());
        showRecyclerList();

    }

    private void showRecyclerList(){
        rvWisatas.setLayoutManager(new LinearLayoutManager(this));
        ListWisataAdapter listWisataAdapter = new ListWisataAdapter(list);
        rvWisatas.setAdapter(listWisataAdapter);
    }
}
